.. toolkit documentation master file, created by
   sphinx-quickstart on Wed Feb  9 17:10:01 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

API - cellDancer key applications
===========================================================================================




Toolkit functions
-------------------


celldancer
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. currentmodule:: celldancer
.. rubric:: Functions

.. autosummary::

   velocity_estimation.velocity
   compute_cell_velocity.compute
   pseudo_time.pseudo_time
   embedding_kinetic_para.embedding
   utilities.adata_to_raw_with_embed


plotting
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
.. currentmodule:: celldancer.plotting
.. rubric:: Functions

.. autosummary::

   gene.scatter_gene
   cell.scatter_cell
   cell.plot_kinetic_para
   graph.graph



