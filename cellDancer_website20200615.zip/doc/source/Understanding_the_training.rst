.. toolkit documentation master file, created by
   sphinx-quickstart on Wed Feb  9 17:10:01 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Understand the decreasing of loss
===========================================================================================
The figure of 'Sulf2' below shows that, the deep neural network is adjusted gradually as the loss get mimized during the training. Finally, the model stops when the spliced reads and unspliced reads get fit and the loss cannot be decreased.

.. image:: images/Sulf2.png
   :width: 600

Below are more examples showing how does the model change during the training.

.. image:: images/training_process.png
   :width: 600