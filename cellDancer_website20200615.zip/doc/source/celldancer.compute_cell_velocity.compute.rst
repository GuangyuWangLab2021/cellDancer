﻿celldancer.compute\_cell\_velocity.compute
==========================================

.. currentmodule:: celldancer.compute_cell_velocity

.. autofunction:: compute