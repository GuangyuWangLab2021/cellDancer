﻿celldancer.embedding\_kinetic\_para.embedding
=============================================

.. currentmodule:: celldancer.embedding_kinetic_para

.. autofunction:: embedding