﻿celldancer.plotting.cell.scatter\_cell
======================================

.. currentmodule:: celldancer.plotting.cell

.. autofunction:: scatter_cell