﻿celldancer.plotting.gene.scatter\_gene
======================================

.. currentmodule:: celldancer.plotting.gene

.. autofunction:: scatter_gene