﻿celldancer.pseudo\_time.pseudo\_time
====================================

.. currentmodule:: celldancer.pseudo_time

.. autofunction:: pseudo_time