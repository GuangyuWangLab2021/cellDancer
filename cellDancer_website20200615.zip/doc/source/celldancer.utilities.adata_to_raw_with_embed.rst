﻿celldancer.utilities.adata\_to\_raw\_with\_embed
================================================

.. currentmodule:: celldancer.utilities

.. autofunction:: adata_to_raw_with_embed