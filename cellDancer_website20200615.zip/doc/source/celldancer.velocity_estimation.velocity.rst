﻿celldancer.velocity\_estimation.velocity
========================================

.. currentmodule:: celldancer.velocity_estimation

.. autofunction:: velocity